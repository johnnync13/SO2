#include <stdio.h>

int main(void)
{
  int i, a[5];

  for(i = 0; i < 5; i++)
    a[i] = 0;

  return 0;
}

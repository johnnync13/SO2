#include <stdio.h>

int main(void)
{
	printf("sizeof(long) = %d\n", sizeof(long));
	return 0;
}
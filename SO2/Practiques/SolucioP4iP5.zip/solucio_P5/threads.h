#pragma once

#include <stdio.h>
#include <pthread.h>

#include "red-black-tree.h"

#define NUM_CONSUMER 4
#define NUM_CELLS    4

#define BLOCK_LINES  10000


/**
 * 
 *  This global variable is used to know when there are no more data to
 *  be put in the cells. This variable is shared between producers and
 *  consumers. We use a global variable to facilitate its use. 
 *
 */

int work_has_finished; 

/**
 * 
 *  This structure holds the information that has to be passed
 *  to the secondary threads.
 *
 */

// One cell of the buffer. The text and the number of elements
// that contain information 
struct cell {
    int nelems;  
    char **line;
};

// This is the communication buffer between the producer and 
// consumers
struct buffer {
    // We store an array of pointers to cells. This will allow us to "play" with pointers.
    // Take a look at the functions producer_copy_to_buffer and consumer_get_from_buffer. 
    struct cell *cells[NUM_CELLS]; 
    int write;
    int read;
    int counter;
};

// The information that is passed to the producer
struct producer_arguments {
    struct buffer *buffer;
    FILE *fp; 
};

// The information that is passed to the consumers
struct consumer_arguments {
    rb_tree *tree;
    struct buffer *buffer;
};

// Producer and consumer
void *thread_producer(void *arg);
void *thread_consumer(void *arg);

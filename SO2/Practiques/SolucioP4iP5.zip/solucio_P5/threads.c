#include <stdlib.h>
#include <pthread.h>
#include <string.h>

#include "threads.h"
#include "ficheros-csv.h"

/* A lock shared between producer and consumer to inform that producer has finished reading data */
pthread_mutex_t lock_global    = PTHREAD_MUTEX_INITIALIZER;

/* A lock needed for the consumer, to introduce data inside the tree */
pthread_mutex_t lock_consumer  = PTHREAD_MUTEX_INITIALIZER;

/* A lock needed to implement the producer-consumer algorithm */
pthread_mutex_t lock_prod_cons = PTHREAD_MUTEX_INITIALIZER;

/* Needed to implement to producer-consumer algorithm */
pthread_cond_t producer = PTHREAD_COND_INITIALIZER;
pthread_cond_t consumer = PTHREAD_COND_INITIALIZER;


/**
 *
 *  This function tranfers the cell information to the buffer. It is a bit
 *  tricky since it performs the next: it takes the cell that is passed as
 *  argment and introduces it in the buffer, whereas the cell that is in the
 *  buffer is taken so that the producer can use it. The cell that is in the
 *  buffer is in fact a cell that can be overwritten. Rather than overwriting
 *  it, we "take" the memory and return it to the producer to that is can be
 *  used. To do this we just play with the pointers.
 *
 */

struct cell *producer_copy_to_buffer(struct buffer *buffer, struct cell *cell)
{
    struct cell *cell_buffer;

    pthread_mutex_lock(&lock_prod_cons);
    while (buffer->counter == NUM_CELLS) {
        pthread_cond_wait(&producer, &lock_prod_cons);
    }

    /* Here is the trick with the pointers!!! */
    cell_buffer = buffer->cells[buffer->write];
    buffer->cells[buffer->write] = cell;

    buffer->write++;
    if (buffer->write == NUM_CELLS)
        buffer->write = 0;

    buffer->counter++;

    pthread_cond_signal(&consumer);
    pthread_mutex_unlock(&lock_prod_cons);

    return cell_buffer;
}

/**
 *
 *  This is the function that gets data from the buffer. It is the equivalent
 *  of the function producer_copy_to_buffer. Here we also play with the
 *  buffers. The consumer gives as argument a cell that contains information
 *  that is not more needed. And it gets a cell that has to be analyzed. Since
 *  we use pointers, we just interchange them.
 *
 */

struct cell *consumer_get_from_buffer(struct buffer *buffer, struct cell *cell)
{
    struct cell *cell_buffer;

    pthread_mutex_lock(&lock_prod_cons);
    while ((buffer->counter == 0) && (!work_has_finished)) {
        pthread_cond_wait(&consumer, &lock_prod_cons);
    }

    if ((buffer->counter == 0) && (work_has_finished))
    {
        /* We notify the consumer that there is no work to be done
         * by setting the number of elements to a negative value. */

        cell_buffer = cell; 
        cell_buffer->nelems = -1; 
    } 
    else { 
        /* This condition is satisfied when there are elements in
         * the buffer to be processed, even if producers have finished
         * (that is, even if the variable work_has_finished is set to true).
         */

        /* Here is the trick with the pointers */
        cell_buffer = buffer->cells[buffer->read];
        buffer->cells[buffer->read] = cell;

        buffer->read++;
        if (buffer->read == NUM_CELLS)
            buffer->read = 0;

        buffer->counter--;
        pthread_cond_signal(&producer);
    }
    pthread_mutex_unlock(&lock_prod_cons);

    return cell_buffer;
}

/**
 *
 *  Funcio consumidor 
 *
 */

void *thread_consumer(void *arg)
{
    struct consumer_arguments *consumer_arguments;

    rb_tree *tree;
    struct buffer *buffer;

    struct cell *cell;

    struct flight_information fi;
    int i, j, invalid, consumer_finished;

    node_data *n_data;
    list_data *l_data;

    /* Argumentos del hilo */
    consumer_arguments = (struct consumer_arguments *) arg;

    buffer = consumer_arguments->buffer;
    tree   = consumer_arguments->tree;

    /* We allocate memory for a cell */
    cell = malloc(sizeof(struct cell));

    cell->nelems = 0;

    cell->line = malloc(sizeof(char *) * BLOCK_LINES);
    for(j = 0; j < BLOCK_LINES; j++)
        cell->line[j] = malloc(sizeof(char *) * MAXCHAR);

    /* Set consumer_finished to zero */
    consumer_finished = 0;

    /* Bucle per llegir dades */
    while (!consumer_finished) {
      /* This is a tricky function: it interchanges the memory of the cell 
         * that the consumer has with the memory of the cell of the buffer.
         * This can be done with a tricky interchange of pointers. It's fast! */

        cell = consumer_get_from_buffer(buffer, cell);

        /* The previous function returns a negative value of elements if there
         * are no more cells to be processed. */

        if (cell->nelems < 0) {
            consumer_finished = 1;
            continue;
        }

        if (cell->nelems >  0)
        {
            i = 0;
            while (i < cell->nelems) {
                invalid = extract_fields_airport(cell->line[i], &fi);

                if (!invalid) {
                    n_data = find_node(tree, fi.origin);

                    if (n_data) {
                        /* Aqui aplicamos el bloqueo */
                        pthread_mutex_lock(&n_data->mutex);

                        l_data = find_list(n_data->l, fi.destination);

                        if (l_data) {
                            l_data->numero_vuelos += 1;
                            l_data->retardo_total += fi.delay;
                        } else {
                            l_data = malloc(sizeof(list_data));

                            l_data->key = malloc(sizeof(char) * 4);
                            strcpy(l_data->key, fi.destination);

                            l_data->numero_vuelos = 1;
                            l_data->retardo_total = fi.delay; 

                            insert_list(n_data->l, l_data);
                        }

                        /* Aqui liberamos el bloqueo */
                        pthread_mutex_unlock(&n_data->mutex);

                    } else {
                        printf("ERROR: aeropuerto %s no encontrado en el arbol.\n", fi.origin);
                        exit(1);
                    }
                }

                i++;
            }
        }
    } 

    /* Liberamos memoria */
    for(i = 0; i < BLOCK_LINES; i++)
        free(cell->line[i]);

    free(cell->line);

    return (void *) NULL;
}


/**
 *
 *  This is the producer. It reads the PDF files and transfers the information
 *  to the buffer. It tries to minimze the time needed to access the buffer.  
 *
 */

void *thread_producer(void *arg)
{
    struct producer_arguments *producer_arguments;

    struct cell *cell;

    FILE *fp; 
    struct buffer *buffer;

    char line[MAXCHAR];
    int j, finished, index;

    producer_arguments = (struct producer_arguments *) arg;

    fp     = producer_arguments->fp;
    buffer = producer_arguments->buffer;

    /* We allocate memory for a cell */

    cell = malloc(sizeof(struct cell));

    cell->nelems = 0;

    cell->line = malloc(sizeof(char *) * BLOCK_LINES);
    for(j = 0; j < BLOCK_LINES; j++)
        cell->line[j] = malloc(sizeof(char *) * MAXCHAR);

    /* Read header of file */
    fgets(line, MAXCHAR, fp);

    /* Read file */
    j = 0;
    finished = 0;
    while (!finished)
    {
        /* Get a block of lines */
        index = 0;
        while ((index < BLOCK_LINES) && (fgets(cell->line[index], MAXCHAR, fp) != NULL))
            index++;

        cell->nelems = index;

        if (index  == 0) {
            finished = 1;
            continue;
        }

        if (index < BLOCK_LINES) 
            finished = 1;

        /* This function is a bit tricky: it inserts the cell passed as argument
         * to the buffer and returns a free cell from the buffer. We just 
         * play with pointers. */                
        cell = producer_copy_to_buffer(buffer, cell); 
    }

    pthread_mutex_lock(&lock_prod_cons);

    work_has_finished = 1;

    pthread_cond_broadcast(&consumer);

    pthread_mutex_unlock(&lock_prod_cons);

    /* Free the cell */
    for(j = 0; j < BLOCK_LINES; j++)
        free(cell->line[j]);

    free(cell->line); 
    free(cell);

    return NULL;
}





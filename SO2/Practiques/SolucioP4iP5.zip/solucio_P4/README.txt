Codi comentat amb la implementaci� d'una possible soluci� per les pr�ctiques 1 i 2 de SO2. 
Inclou el codi, les cap�aleres i el Makefile.
Podeu fer servir aquest codi com a punt de partida per seguir fent les pr�ctiques 3 i 4 o b� com a refer�ncia pel vostre propi codi.

 
docker build -t prova2 .
docker run -ti prova2

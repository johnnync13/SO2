Instruccions 

--------

df -i

Permet saber quants i-nodes es fan servir a cada dispositiu

--------

stat

Permet saber les estadístiques de cada fitxer, incloent l'i-node assignat a cada fitxer

--------

ls -i

Permet saber l'i-node assignat a un fitxer

-------

debugfs

Es un debugger per a sistemes de fitxers. S'indica que permet saber els blocs que s'han assignat
a un fitxer. Encara no he aconseguit fer-ho. Es una eina que pot ser perillosa atès que permet
manipular un sistema de fitxers.



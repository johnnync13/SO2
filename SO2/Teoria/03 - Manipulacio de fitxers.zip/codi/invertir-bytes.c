#include <stdio.h>
#include <stdlib.h>

int main(void)
{
  unsigned int a = 1634496328;
  unsigned int b;
  char *str, *invertit;

  str = &a;
  invertit = &b;

  invertit[0] = str[3];
  invertit[1] = str[2];
  invertit[2] = str[1];
  invertit[3] = str[0];

  printf("Original: %u, Invertit: %u\n", a, b);

  return 0;
}

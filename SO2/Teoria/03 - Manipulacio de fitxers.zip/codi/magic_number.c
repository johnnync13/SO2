#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
  unsigned char str[5];

  FILE *fp;

  if (argc != 2) {
    printf("Us: %s <fitxer>\n", argv[0]);
    exit(1);
  }

  fp = fopen(argv[1], "r");
  if (!fp) {
    printf("No he pogut obrir '%s'\n", argv[1]);
    exit(1);
  }

  fread(str, sizeof(char), 4, fp);
  fclose(fp);

  str[4] = 0;
  printf("ASCII: '%s'\n", str);
  printf("Decimal: %u %u %u %u\n", str[0], str[1], str[2], str[3]);
  printf("Hexadecimal: %x %x %x %x\n", str[0], str[1], str[2], str[3]);
}

  

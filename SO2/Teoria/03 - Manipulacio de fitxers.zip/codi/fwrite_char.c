#include <stdio.h>

void main(void)
{
  FILE *fp;
  int i;
  
  char *a = "test";
  
  fp = fopen("log_fopen.data", "w");
  
  for(i = 0; i < 100; i++)
    fwrite(a, sizeof(char), 4, fp);
  
  close(fp);
}

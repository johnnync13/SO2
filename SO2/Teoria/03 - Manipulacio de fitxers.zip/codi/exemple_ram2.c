#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
  char *str;
  unsigned int *a;

  str = malloc(sizeof(char) * 5);
  strcpy(str, "Hola");

  a = str;

  printf("Cadena: %s\n", str);
  printf("Ascii: %d, %d, %d, %d i el %d\n", 
                 str[0], str[1], str[2], str[3], str[4]);
  printf("Sencer: %u\n", *a);
  printf("-----------------------\n");

  *a = 97;

  printf("Cadena: %s\n", str);
  printf("Ascii: %d, %d, %d, %d i el %d\n", 
                 str[0], str[1], str[2], str[3], str[4]);
  printf("Sencer: %u\n", *a);

  return 0;
}
